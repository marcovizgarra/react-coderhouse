// Aquí vas a poner tu array de productos

// Va un ejemplo, debería de verse así. Pongan sus propios objetos abajo.

// const arrayProductos = [
//     {
//         nombre: "1"
//     },
//     {
//         nombre: "2"
//     },
//     {
//         nombre: "3"
//     },
//     {
//         nombre: "4"
//     },
// ];

const arrayProductos = [

];